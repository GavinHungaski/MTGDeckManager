-- Initialize MTG Deck Manager Database
-- Run this script on your AWS RDS PostgreSQL instance to create the required tables

-- Drop existing tables in correct cascade order
DROP TABLE IF EXISTS deck_cards CASCADE;
DROP TABLE IF EXISTS cards CASCADE;
DROP TABLE IF EXISTS decks CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- Drop existing functions
DROP FUNCTION IF EXISTS update_updated_at_column() CASCADE;

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(100) NOT NULL UNIQUE,
    email TEXT NOT NULL,  -- Encrypted email
    email_hash VARCHAR(64) NOT NULL UNIQUE,  -- SHA256 hash for searching
    password_hash TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create index on email_hash for faster login lookups
CREATE INDEX IF NOT EXISTS idx_users_email_hash ON users(email_hash);

-- Decks table
CREATE TABLE IF NOT EXISTS decks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(200) NOT NULL,
    format VARCHAR(50) DEFAULT 'Commander',
    description TEXT,
    commander_card_id VARCHAR(100),  -- Scryfall card ID
    is_public BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for decks
CREATE INDEX IF NOT EXISTS idx_decks_user_id ON decks(user_id);
CREATE INDEX IF NOT EXISTS idx_decks_format ON decks(format);

-- Cards table (references Scryfall data)
CREATE TABLE IF NOT EXISTS cards (
    id VARCHAR(100) PRIMARY KEY,  -- Scryfall card ID
    name VARCHAR(200) NOT NULL,
    mana_cost VARCHAR(50),
    cmc NUMERIC,  -- Converted mana cost
    card_type TEXT,
    oracle_text TEXT,
    power VARCHAR(10),
    toughness VARCHAR(10),
    loyalty VARCHAR(10),
    artist VARCHAR(100),
    rarity VARCHAR(20),
    prices JSONB,
    color_identity TEXT,  -- Array of color letters (W, U, B, R, G)
    keywords TEXT[],  -- Array of keyword abilities
    legalities JSONB,  -- Legality in different formats
    edhrec_rank INTEGER,  -- EDHREC popularity rank
    types JSONB,
    front_image TEXT,
    back_image TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for cards
CREATE INDEX IF NOT EXISTS idx_cards_color_identity ON cards USING GIN (color_identity);
CREATE INDEX IF NOT EXISTS idx_cards_cmc ON cards(cmc);
CREATE INDEX IF NOT EXISTS idx_cards_edhrec_rank ON cards(edhrec_rank);

-- Deck cards junction table
CREATE TABLE IF NOT EXISTS deck_cards (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    deck_id UUID NOT NULL REFERENCES decks(id) ON DELETE CASCADE,
    card_id VARCHAR(100) NOT NULL REFERENCES cards(id),
    quantity INTEGER NOT NULL DEFAULT 1,
    is_commander BOOLEAN DEFAULT false,
    is_sideboard BOOLEAN DEFAULT false,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(deck_id, card_id)
);

-- Create indexes for deck_cards
CREATE INDEX IF NOT EXISTS idx_deck_cards_deck_id ON deck_cards(deck_id);
CREATE INDEX IF NOT EXISTS idx_deck_cards_card_id ON deck_cards(card_id);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_decks_updated_at BEFORE UPDATE ON decks
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_deck_cards_updated_at BEFORE UPDATE ON deck_cards
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert a test user (optional - remove in production)
-- Password: password123 (hashed with bcrypt)
-- NOTE: You should create users through the registration endpoint instead
-- INSERT INTO users (username, email, email_hash, password_hash) 
-- VALUES ('testuser', 'encrypted_email_here', 'hash_of_email', 'hashed_password');
